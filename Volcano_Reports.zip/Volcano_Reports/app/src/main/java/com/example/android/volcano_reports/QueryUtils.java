package com.example.android.volcano_reports;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class QueryUtils {
    private static String LOG_TAG = "Test_Error";
    private static String LOG_TAG_results = "Test_Result";

    private QueryUtils(){

    }

    private static URL createUrl(String stringUrl){
        URL url = null;
        try {
            url = new URL(stringUrl);
        }catch (MalformedURLException e){
            Log.e(LOG_TAG,"Unable to build URL", e);
        }
        return url;
    }

    private static String makeHttpRequest(URL url) throws IOException{
        String jsonResponse = "";

        if (url == null){
            return jsonResponse;
        }
        HttpURLConnection urlConnection = null;
        InputStream inputStream = null;
        try {
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setReadTimeout(10000);
            urlConnection.setConnectTimeout(15000);
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            if (urlConnection.getResponseCode() == 200){
                inputStream = urlConnection.getInputStream();
                jsonResponse = readFromStream(inputStream);
            }else {
                Log.e(LOG_TAG, "Error response code" + urlConnection.getResponseCode());
            }
        }catch (IOException e){
            Log.e(LOG_TAG, "Error retrieving JSON results", e);
        }finally {
            if (urlConnection != null){
                urlConnection.disconnect();
            }
            if (inputStream != null){
                inputStream.close();
            }
        }
        return jsonResponse;
    }

    private static String readFromStream(InputStream inputStream) throws IOException {
        StringBuilder result = new StringBuilder();
        if (inputStream != null){
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream,
                    Charset.forName("UTF-8"));
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String read = bufferedReader.readLine();
            while (read != null){
                result.append(read);
                read = bufferedReader.readLine();
            }
        }
        return result.toString();
    }
    public static ArrayList<Volcano> fetchVolcanoFromJson(String sourceJson){
        ArrayList<Volcano> arrayList = new ArrayList<>();
        try {
            JSONObject baseJsonResponse = new JSONObject(sourceJson);
            JSONObject response = baseJsonResponse.getJSONObject("response");
            JSONArray jsonArray = response.getJSONArray("results");

            for (int i = 0; i < jsonArray.length(); i++){
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String V_Name = jsonObject.getString("V_Name");
                String Country = jsonObject.getString("Country");
                String Region = jsonObject.getString("Region");

                Log.i(LOG_TAG_results, V_Name);
                Log.i(LOG_TAG_results, Country);
                Log.i(LOG_TAG_results, Region);

                Volcano volcano = new Volcano(V_Name, Country, Region);
                arrayList.add(volcano);
            }
        }catch (JSONException e){
            Log.i(LOG_TAG,"error extracting features: " + e.toString());
        }
        return arrayList;
    }
    public static List<Volcano> fetchVolcano(String requestUrl){
        URL url = createUrl(requestUrl);

        String jsonResponse= null;
        try {
            jsonResponse = makeHttpRequest(url);
        }catch (IOException e){
            Log.e(LOG_TAG, "Erro accessing HTTP request", e);
        }
        List<Volcano> volcanoes = fetchVolcanoFromJson(jsonResponse);
        return volcanoes;
    }
}
