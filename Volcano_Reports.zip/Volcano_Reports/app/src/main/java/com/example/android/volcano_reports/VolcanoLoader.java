package com.example.android.volcano_reports;

import android.content.Context;
import android.os.AsyncTask;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.loader.content.AsyncTaskLoader;

public class VolcanoLoader extends AsyncTaskLoader<List<Volcano>> {

    private String mURL;

    public VolcanoLoader(@NonNull Context context, String url) {
        super(context);
        mURL = url;
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }

    @Nullable
    @Override
    public List<Volcano> loadInBackground() {
        if (mURL == null){
            return null;
        }
        List<Volcano> volcanoList =
                com.example.android.volcano_reports.QueryUtils.fetchVolcano(mURL);
        return volcanoList;

    }
}
