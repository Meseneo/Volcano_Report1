package com.example.android.volcano_reports;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<Volcano>> {
    private VolcanoAdapter volcanoAdapter;

    private static final String REQUEST_URL ="\n" +
            "https://s3.eu-central-1.amazonaws.com";

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ConnectivityManager connectivityManager =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        volcanoAdapter = new VolcanoAdapter(this, new ArrayList<Volcano>());
        ListView listView = findViewById(R.id.list_view);

        ListAdapter listAdapter = null;
        listView.setAdapter(listAdapter);

      ///////////////////////////////////////////////////////////////////////

        Network networkInfo = connectivityManager.getActiveNetwork();
        if (networkInfo != null && networkInfo.isConnected()){

            android.app.LoaderManager loaderManager = getLoaderManager();
            loaderManager.initLoader(0,null, (android.app.LoaderManager.LoaderCallbacks<Object>) this);
        }else {
            Toast.makeText(this, "No internet connection", Toast.LENGTH_SHORT).show();
        }
    }

    @NonNull
    @Override
    public Loader<List<Volcano>> onCreateLoader(int id, @Nullable Bundle args) {
        Uri base = Uri.parse(REQUEST_URL);

        Uri.Builder uriBuilder = base.buildUpon();

        uriBuilder.appendQueryParameter("show_tags", "contributors");
        uriBuilder.appendQueryParameter("api-key", "test");

        return new Volcano(this, uriBuilder.toString());
    }

    @Override
    public void onLoadFinished(@NonNull Loader<List<Volcano>> loader, List<Volcano> data) {
        volcanoAdapter.clear();

        if (data != null && !data.isEmpty()){
            volcanoAdapter.addAll((Collection<? extends Volcano>) data);
        }

    }

    @Override
    public void onLoaderReset(@NonNull Loader<List<Volcano>> loader) {

        volcanoAdapter.clear();

    }
}