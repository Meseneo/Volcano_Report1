package com.example.android.volcano_reports;

public class Volcano {
    private String mV_Name;
    private String mCountry;
    private String mRegion;

    public Volcano(String v_name, String country, String region){
        mV_Name = v_name;
        mCountry = country;
        mRegion = region;
    }


    /*Generate Getter*/
    public String getV_Name() {
        return mV_Name;
    }

    public String getCountry() {
        return mCountry;
    }

    public String getRegion() {
        return mRegion;
    }
}
