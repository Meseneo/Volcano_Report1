package com.example.android.volcano_reports;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class VolcanoAdapter extends ArrayAdapter<Volcano> {

    /*Create or Implement constructor matching super class */
    public VolcanoAdapter(@NonNull Context context, ArrayList<Volcano> arrayList) {
        super(context, 0, arrayList);
    }

    public VolcanoAdapter(@NonNull Context context, int resource) {
        super(context, resource);
    }

    /* Create a getter for the View*/

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View currentListView = convertView;

        if (currentListView == null) {
            currentListView = LayoutInflater.from(getContext()).inflate(R.layout.list_items,
                    parent, false);
        }

        Volcano volcano = getItem(position);

        TextView v_nameView = currentListView.findViewById(R.id.vName);
        v_nameView.setText(volcano.getV_Name());

        TextView countryView = currentListView.findViewById(R.id.vCountry);
        countryView.setText(volcano.getCountry());

        TextView regionView = currentListView.findViewById(R.id.vRegion);
        regionView.setText(volcano.getRegion());

        return currentListView;
    }
}